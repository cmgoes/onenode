export const KeyContractAddress = "0x0a1e2B30e23d89EA44669F40C49f2D80E3C9beAA";
export const LootBoxContractAddress = "0xC5217de848035e7E35984a6dCfb1678760601c97";
export const FantomRegisterNFTAddress = "0xC0946d281e2C97334C667a7b517691b9EA492775";
export const PumpkinRegisterNFTAddress = "0xc38f753f581e121aB21b73cd2C4FD96d15A21b17";
export const TombRegisterNFTAddress = "0x13fb2a8C98c122d5660e10e0354bf44f9717E504";
export const DaiRegisterNFTAddress = "0xF80de1DfCf6F944b7a44c9627792fF0333917258";
export const RewardContractAddress = "0x8D11eC38a3EB5E956B052f67Da8Bdc9bef8Abf3E";
export const DaiStakeOneContractAddress = "0xc58bD5c11ca40A742Dd6eAa29Fe4d7bD1E50F098";
export const DaiStakeTwoContractAddress = "0x891126d2477a4De3892b178CdD76C5E9076EafC8";
export const PumpkinContractAddress = "0xAD522217E64Ec347601015797Dd39050A2a69694";
export const NodeContractAddress = "0x4d490C2031964C495bFD50D5Bc988516764b314e";



