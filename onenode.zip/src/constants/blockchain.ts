export const TOKEN_DECIMALS = 9;

export enum Networks {
    // AVAX = 43114,
    FTM = 250, // for test
}

export const DEFAULD_NETWORK = Networks.FTM;
