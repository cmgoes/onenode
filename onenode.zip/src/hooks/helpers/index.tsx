export const getMainnetURI = (): string => {
  return "https://rpc.ftm.tools/";
  return "https://rpc.ftm.tools/";
};
