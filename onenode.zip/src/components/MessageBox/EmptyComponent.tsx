export default function emptyComponent () {
  return (
    <></>
  )
}